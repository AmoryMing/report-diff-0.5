import React, { useState } from 'react';
import { ReportInput } from './components/ReportInput';
import { PromptDebugger } from './components/PromptDebugger';
import { ComparisonResults } from './components/ComparisonResults';
import { ComparisonResultsStream } from './components/ComparisonResultsStream';
import { OptimizationSuggestions } from './components/OptimizationSuggestions';
import { Card } from './components/ui/card';
import { Button } from './components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { FileText, Brain, TrendingUp } from 'lucide-react';

import { Report, ComparisonResult, DataValidation } from './components/types';

// 辅助函数：获取分析重点详情
const getAnalysisPromptDetails = (mode: string): string => {
  const detailMap: Record<string, string> = {
    comprehensive: '- 内容完整性：信息覆盖面、关键要素缺漏、论述深度差异\n- 逻辑框架：结构合理性、论证链条完整性、因果关系清晰度\n- 数据支撑：量化证据充分性、数据可信度、图表有效性\n- 实用价值：决策支持力度、可操作性建议、预期效果评估',
    data: '- 数据来源：权威性、时效性、覆盖范围、样本代表性\n- 数据质量：准确性、完整性、一致性、异常值处理\n- 分析方法：统计模型选择、计算逻辑、趋势预测合理性\n- 可视化效果：图表类型适配性、信息传达清晰度、视觉冲击力\n- 结论支撑：数据与观点匹配度、推论严谨性',
    business: '- 战略洞察：市场趋势把握、竞争态势分析、机会识别精准度\n- 风险评估：潜在威胁预警、风险量化程度、应对策略完备性\n- 执行指导：行动方案具体性、资源配置建议、时间节点规划\n- ROI分析：投入产出预期、成本效益评估、财务影响量化\n- 决策支持：关键问题解答、多情景预案、KPI设定',
    structure: '- 整体架构：信息层次设计、章节逻辑关系、内容流转顺畅度\n- 论证体系：观点提出顺序、证据支撑链条、反驳预期处理\n- 表达技巧：语言准确性、专业术语使用、读者理解友好度\n- 格式规范：标题体系、段落结构、视觉呈现一致性\n- 阅读体验：信息检索便利性、重点突出效果、记忆点设置',
    research: '- 方法论：研究设计科学性、调研方法适配性、样本选择合理性、变量控制有效性\n- 创新价值：观点原创性、理论贡献度、实践启发性、行业突破性\n- 文献基础：引用权威性、理论溯源完整性、前沿动态把握、知识体系构建\n- 验证严谨性：假设检验充分性、结论推导逻辑性、局限性坦诚度\n- 学术影响：可复制性、可推广性、后续研究价值'
  };
  return detailMap[mode] || detailMap.comprehensive;
};

export default function App() {
  const [reports, setReports] = useState<{ report1: Report | null; report2: Report | null }>({
    report1: null,
    report2: null,
  });
  
  const [customPrompt, setCustomPrompt] = useState(
    "作为专业分析师，请全面对比这两份报告的综合质量。重点分析：1）内容完整性：信息覆盖面、关键要素缺漏、论述深度差异；2）逻辑框架：结构合理性、论证链条完整性、因果关系清晰度；3）数据支撑：量化证据充分性、数据可信度、图表有效性；4）实用价值：决策支持力度、可操作性建议、预期效果评估。请提供具体的优劣势对比和改进建议。"
  );
  
  const [selectedAnalysisMode, setSelectedAnalysisMode] = useState({
    id: 'comprehensive',
    name: '综合对比',
    prompt: "作为专业分析师，请全面对比这两份报告的综合质量。重点分析：1）内容完整性：信息覆盖面、关键要素缺漏、论述深度差异；2）逻辑框架：结构合理性、论证链条完整性、因果关系清晰度；3）数据支撑：量化证据充分性、数据可信度、图表有效性；4）实用价值：决策支持力度、可操作性建议、预期效果评估。请提供具体的优劣势对比和改进建议。"
  });
  const [activeTab, setActiveTab] = useState('input');
  const [useStreamingMode, setUseStreamingMode] = useState(true); // 控制是否使用流式模式
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);
  const [selectedPerspective, setSelectedPerspective] = useState<'report1' | 'report2'>('report1');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // 缓存机制：简化缓存键，只使用核心标识
  const [analysisCache, setAnalysisCache] = useState<Record<string, any>>({});

  const handleReportUpdate = (reportId: 'report1' | 'report2', report: Report) => {
    setReports(prev => ({
      ...prev,
      [reportId]: report
    }));
    
    // 清空分析结果缓存，因为报告内容已更改
    setAnalysisCache({});
    setComparisonResult(null);
  };

  // 根据分析模式生成对应的结论和分析
  const generateAnalysisByMode = (mode: string, winnerReport: Report, loserReport: Report) => {
    const analysisTemplates: Record<string, { conclusion: string; detailedAnalysis: string }> = {
      comprehensive: {
        conclusion: `${winnerReport.title}在综合质量评估中表现优异，在内容完整性、逻辑框架、数据支撑和实用价值四个维度均展现出明显优势。`,
        detailedAnalysis: `通过全面分析对比，${winnerReport.title}在综合质量上更胜一筹。从内容完整性看，该报告信息覆盖面更广，关键要素齐全，论述深度适中；逻辑框架方面，结构合理性突出，论证链条完整，因果关系清晰；在数据支撑维度，量化证据充分，数据可信度高，图表展示有效；实用价值层面，决策支持力度强，提供了可操作性建议，预期效果评估合理。相比之下，${loserReport.title}虽然也有亮点，但在整体协调性和深度分析方面仍有提升空间。`
      },
      data: {
        conclusion: `${winnerReport.title}在数据质量和分析深度方面表现卓越，数据支撑更加权威可信，分析方法更加科学严谨。`,
        detailedAnalysis: `从数据分析专业角度评估，${winnerReport.title}展现出更高的数据质量标准。在数据来源方面，该报告引用了更多权威、时效性强的数据源，样本覆盖范围更广，代表性更强；数据质量上，准确性、完整性和一致性表现突出，异常值处理得当；分析方法选择更加科学，统计模型适配性好，计算逻辑清晰，趋势预测合理；可视化效果优秀，图表类型与数据特征匹配，信息传达清晰，视觉冲击力强；在结论支撑方面，数据与观点匹配度高，推论严谨可信。${loserReport.title}虽然数据丰富，但在数据验证和分析深度上略有不足。`
      },
      business: {
        conclusion: `${winnerReport.title}从商业价值角度更具优势，在战略洞察、风险评估和执行指导方面为企业决策提供了更强有力的支持。`,
        detailedAnalysis: `从商业决策制定角度评估，${winnerReport.title}展现出更高的商业价值。在战略洞察维度，该报告对市场趋势把握精准，竞争态势分析透彻，机会识别具有前瞻性；风险评估方面，潜在威胁预警及时，风险量化程度高，应对策略完备可行；执行指导层面，行动方案具体可操作，资源配置建议合理，时间节点规划清晰；ROI分析详实，投入产出预期明确，成本效益评估客观，财务影响量化准确；决策支持功能强大，关键问题解答充分，多情景预案设计完备，KPI设定科学合理。相比之下，${loserReport.title}在战略高度和执行落地之间的平衡上仍需加强。`
      },
      structure: {
        conclusion: `${winnerReport.title}在结构逻辑和表达效果方面更加出色，整体架构合理，论证体系严密，阅读体验优良。`,
        detailedAnalysis: `从文档架构和逻辑组织角度分析，${winnerReport.title}表现更加优异。整体架构设计科学，信息层次清晰，章节逻辑关系紧密，内容流转顺畅自然；论证体系完整严密，观点提出顺序合理，证据支撑链条完整，对潜在反驳的预期处理得当；表达技巧娴熟，语言准确性高，专业术语使用恰当，对读者理解友好；格式规范统一，标题体系层次分明，段落结构合理，视觉呈现一致性好；阅读体验优良，信息检索便利，重点突出效果明显，记忆点设置巧妙。${loserReport.title}虽然内容丰富，但在结构组织和逻辑递进方面还有优化空间。`
      },
      research: {
        conclusion: `${winnerReport.title}在研究方法和学术价值方面更具优势，研究设计科学严谨，创新价值突出，学术贡献度更高。`,
        detailedAnalysis: `从学术研究标准评估，${winnerReport.title}展现出更高的研究质量。方法论方面，研究设计科学合理，调研方法与研究目标适配性强，样本选择具有代表性，变量控制有效；创新价值显著，观点具有原创性，理论贡献度高，对实践具有启发意义，在行业内具有突破性；文献基础扎实，引用权威性强，理论溯源完整，对前沿动态把握准确，知识体系构建完善；验证严谨性高，假设检验充分，结论推导逻辑性强，对研究局限性坦诚说明；学术影响力强，研究具有可复制性和可推广性，为后续研究提供了价值。${loserReport.title}虽然也有一定学术价值，但在研究深度和方法创新方面仍需提升。`
      }
    };

    return analysisTemplates[mode] || analysisTemplates.comprehensive;
  };

  const runComparison = async () => {
    if (!reports.report1 || !reports.report2) return;
    
    // 简化缓存键，只使用核心标识符
    const cacheKey = `${reports.report1.title.substring(0, 10)}-${reports.report2.title.substring(0, 10)}-${selectedAnalysisMode.id}`;
    
    // 检查是否已有缓存结果
    if (analysisCache[cacheKey]) {
      console.log('Using cached analysis result:', cacheKey);
      setComparisonResult(analysisCache[cacheKey]);
      setActiveTab('analysis');
      return;
    }
    
    setIsAnalyzing(true);
    console.log('Starting new analysis...', { cacheKey });
    
    // 模拟AI分析过程
    setTimeout(() => {
      const wordCountDiff = reports.report1!.wordCount - reports.report2!.wordCount;
      const wordCountPercentage = Math.abs(wordCountDiff) / Math.max(reports.report1!.wordCount, reports.report2!.wordCount) * 100;
      
      // 模拟数据验证 - 去掉冲突项
      const mockDataValidation: DataValidation[] = [
        {
          value: '1250万元',
          source: 'report1',
          status: 'correct',
          suggestion: '数据来源可靠，无需验证'
        },
        {
          value: '15.3%',
          source: 'both',
          status: 'correct'
        },
        {
          value: '890万',
          source: 'report2',
          status: 'suspicious',
          suggestion: '经web搜索验证，建议核实统计口径，可能存在计算差异'
        },
        {
          value: '23.8%',
          source: 'report1',
          status: 'suspicious',
          suggestion: '经web搜索对比，市场份额数据与第三方权威报告存在差异，建议进一步核实'
        }
      ];

      const report1Score = 0.82;
      const report2Score = 0.78;
      const winnerReport = report1Score > report2Score ? reports.report1! : reports.report2!;
      const loserReport = report1Score > report2Score ? reports.report2! : reports.report1!;
      
      const analysisContent = generateAnalysisByMode(selectedAnalysisMode.id, winnerReport, loserReport);
      
      const mockResult: ComparisonResult = {
        overallDifference: 0, // 不再需要显示
        winner: report1Score > report2Score ? 'report1' : report2Score > report1Score ? 'report2' : 'tie',
        confidenceLevel: 'high', // 不再需要显示
        
        metrics: {
          wordCount: {
            report1: reports.report1!.wordCount,
            report2: reports.report2!.wordCount,
            difference: wordCountDiff,
            percentage: wordCountPercentage
          },
          dataValidation: mockDataValidation
        },
        
        analysis: {
          conclusion: analysisContent.conclusion,
          detailedAnalysis: analysisContent.detailedAnalysis,
          
          dimensions: {
            dataQuality: {
              report1: 0.85,
              report2: 0.78,
              analysis: '报告1数据源更加权威，引用了更多官方统计数据；报告2数据颗粒度更细，但部分数据需要进一步验证。'
            },
            structure: {
              report1: 0.82,
              report2: 0.88,
              analysis: '报告2在结构设计上更加合理，信息层次清晰，阅读体验更佳；报告1虽然逻辑严密，但层次略显复杂。'
            },
            logic: {
              report1: 0.89,
              report2: 0.76,
              analysis: '报告1论证逻辑更加严密，推理过程清晰；报告2在某些关键结论的论证上略显不足。'
            },
            content: {
              report1: 0.77,
              report2: 0.83,
              analysis: '报告2在内容深度上更胜一筹，提供了更多实用的操作建议；报告1偏重理论分析，实践指导性相对较弱。'
            }
          }
        }
      };
      
      setComparisonResult(mockResult);
      
      // 缓存分析结果，使用同样的缓存键
      setAnalysisCache(prev => ({
        ...prev,
        [cacheKey]: mockResult
      }));
      
      setIsAnalyzing(false);
      console.log('Analysis completed and cached with key:', cacheKey);
      
      // 分析完成后自动跳转到对比分析页面
      setActiveTab('analysis');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* 头部 */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-2">
            <FileText className="h-8 w-8 text-blue-600" />
            智能报告对比分析工具
          </h1>
          <p className="text-gray-600">
            通过AI深度分析报告差异，提供个性化优化建议
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="input" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              报告输入
            </TabsTrigger>
            <TabsTrigger value="analysis" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              对比分析
            </TabsTrigger>
            <TabsTrigger value="suggestions" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              优化建议
            </TabsTrigger>
          </TabsList>

          <TabsContent value="input" className="space-y-6">
            {/* 报告输入区域 */}
            <div className="grid lg:grid-cols-2 gap-6">
              <ReportInput
                reportId="report1"
                title="报告 1"
                onReportUpdate={handleReportUpdate}
              />
              <ReportInput
                reportId="report2"
                title="报告 2"
                onReportUpdate={handleReportUpdate}
              />
            </div>

            {/* 提示词调试 */}
            <PromptDebugger
              customPrompt={customPrompt}
              onPromptChange={(analysis) => {
                setCustomPrompt(analysis.prompt);
                setSelectedAnalysisMode(analysis);
              }}
            />

            {/* 分析按钮和模式选择 */}
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center gap-4">
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={useStreamingMode}
                    onChange={(e) => setUseStreamingMode(e.target.checked)}
                    className="rounded border-gray-300"
                  />
                  启用流式输出模式
                </label>
              </div>
              <Button
                onClick={runComparison}
                disabled={!reports.report1 || !reports.report2 || isAnalyzing}
                size="lg"
                className="px-8"
              >
                {isAnalyzing ? '分析中...' : '开始对比分析'}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="analysis">
            {comparisonResult ? (
              useStreamingMode ? (
                <ComparisonResultsStream
                  result={comparisonResult}
                  reports={reports}
                  analysisMode={selectedAnalysisMode.id}
                  analysisModeInfo={selectedAnalysisMode}
                />
              ) : (
                <ComparisonResults
                  result={comparisonResult}
                  reports={reports}
                  analysisMode={selectedAnalysisMode.id}
                  analysisModeInfo={selectedAnalysisMode}
                />
              )
            ) : (
              <Card className="p-12 text-center">
                <p className="text-gray-500">请先完成报告输入并运行分析</p>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="suggestions">
            {comparisonResult ? (
              <OptimizationSuggestions
                result={comparisonResult}
                reports={reports}
                selectedPerspective={selectedPerspective}
                onPerspectiveChange={setSelectedPerspective}
                analysisMode={selectedAnalysisMode.id}
                analysisModeInfo={selectedAnalysisMode}
              />
            ) : (
              <Card className="p-12 text-center">
                <p className="text-gray-500">请先完成对比分析以获取优化建议</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}