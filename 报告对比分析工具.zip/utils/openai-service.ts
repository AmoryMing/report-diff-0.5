import { projectId, publicAnonKey } from './supabase/info';

interface DataPoint {
  category: string;
  value: string;
  unit: string;
}

interface DataExtractionResult {
  report1DataPoints: DataPoint[];
  report2DataPoints: DataPoint[];
  unionCategories: string[];
}

interface ComprehensiveAnalysisResult {
  conclusion: string;
  detailedAnalysis: string;
}

interface LearningDimensionsResult {
  structure: string;
  content: string;
  dataQuality: string;
  logic: string;
}

export class OpenAIService {
  private baseUrl: string;

  constructor() {
    this.baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-c4106c46`;
  }

  // 生成优化建议的简述
  async generateOptimizationSummary(
    reportTitle: string,
    otherReportTitle: string,
    isWinning: boolean,
    analysisType: string
  ): Promise<string> {
    try {
      const response = await fetch(`${this.baseUrl}/ai/generate-summary`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          reportTitle,
          otherReportTitle,
          isWinning,
          analysisType
        })
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      return data.summary || '';
    } catch (error) {
      console.error('Generate summary failed:', error);
      throw error;
    }
  }

  // 生成具体执行项列表
  async generateActionItems(
    reportTitle: string,
    otherReportTitle: string,
    isWinning: boolean,
    analysisType: string,
    learningPoints: string[]
  ): Promise<string[]> {
    try {
      const response = await fetch(`${this.baseUrl}/ai/generate-actions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          reportTitle,
          otherReportTitle,
          isWinning,
          analysisType,
          learningPoints
        })
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      return data.actions || [];
    } catch (error) {
      console.error('Generate actions failed:', error);
      throw error;
    }
  }

  // 提取数据点 - 流式版本
  async extractDataPointsStream(
    report1Content: string,
    report2Content: string,
    report1Title: string,
    report2Title: string,
    onProgress?: (progress: number, message: string) => void,
    onToken?: (token: string, accumulated: number) => void
  ): Promise<DataExtractionResult> {
    console.log('=== Frontend: Calling extractDataPointsStream ===', {
      url: `${this.baseUrl}/ai/extract-data-points-stream`,
      report1Title,
      report2Title
    });
    
    try {
      const response = await fetch(`${this.baseUrl}/ai/extract-data-points-stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          report1Content,
          report2Content,
          report1Title,
          report2Title
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Extract data points stream server error:', {
          status: response.status,
          statusText: response.statusText,
          errorText
        });
        throw new Error(`Server error: ${response.status} - ${errorText}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let result: DataExtractionResult = { report1DataPoints: [], report2DataPoints: [], unionCategories: [] };
      
      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6);
              try {
                const parsed = JSON.parse(data);
                
                if (parsed.type === 'progress' && onProgress) {
                  onProgress(parsed.progress, parsed.message);
                } else if (parsed.type === 'token' && onToken) {
                  onToken(parsed.content, parsed.accumulated);
                } else if (parsed.type === 'complete') {
                  result = parsed.data;
                } else if (parsed.type === 'error') {
                  throw new Error(parsed.message);
                }
              } catch (e) {
                // 忽略解析错误
                console.warn('Parse error:', e);
              }
            }
          }
        }
      }
      
      console.log('Extract data points stream success:', result);
      return result;
    } catch (error) {
      console.error('Extract data points stream failed:', error);
      return {
        report1DataPoints: [],
        report2DataPoints: [],
        unionCategories: []
      };
    }
  }

  // 提取数据点 - 原版本（保持向后兼容）
  async extractDataPoints(
    report1Content: string,
    report2Content: string,
    report1Title: string,
    report2Title: string
  ): Promise<DataExtractionResult> {
    console.log('=== Frontend: Calling extractDataPoints ===', {
      url: `${this.baseUrl}/ai/extract-data-points`,
      report1Title,
      report2Title,
      report1ContentLength: report1Content?.length || 0,
      report2ContentLength: report2Content?.length || 0
    });
    
    try {
      const response = await fetch(`${this.baseUrl}/ai/extract-data-points`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          report1Content,
          report2Content,
          report1Title,
          report2Title
        })
      });

      console.log('Extract data points response:', {
        ok: response.ok,
        status: response.status,
        statusText: response.statusText
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Extract data points server error:', {
          status: response.status,
          statusText: response.statusText,
          errorText
        });
        throw new Error(`Server error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      console.log('Extract data points success:', data);
      return data;
    } catch (error) {
      console.error('Extract data points failed:', error);
      // 返回默认数据
      return {
        report1DataPoints: [],
        report2DataPoints: [],
        unionCategories: []
      };
    }
  }

  // 生成数据验证建议
  async generateDataValidationSuggestion(
    category: string,
    report1Value?: string,
    report2Value?: string,
    status: string = 'unknown'
  ): Promise<string> {
    try {
      const response = await fetch(`${this.baseUrl}/ai/generate-data-validation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          category,
          report1Value,
          report2Value,
          status
        })
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      return data.suggestion || '建议进一步核实数据来源';
    } catch (error) {
      console.error('Generate data validation suggestion failed:', error);
      return '建议进一步核实数据来源';
    }
  }

  // 生成AI综合评估 - 流式版本
  async generateComprehensiveAnalysisStream(
    report1Content: string,
    report2Content: string,
    report1Title: string,
    report2Title: string,
    analysisMode: string,
    winner: string,
    analysisModeName?: string,
    analysisDimensionsText?: string,
    onProgress?: (progress: number, message: string) => void,
    onToken?: (token: string, accumulated: number) => void
  ): Promise<ComprehensiveAnalysisResult> {
    console.log('=== Frontend: Calling generateComprehensiveAnalysisStream ===', {
      url: `${this.baseUrl}/ai/generate-comprehensive-analysis-stream`,
      report1Title,
      report2Title,
      analysisMode,
      winner,
      analysisModeName
    });
    
    try {
      const response = await fetch(`${this.baseUrl}/ai/generate-comprehensive-analysis-stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          report1Content,
          report2Content,
          report1Title,
          report2Title,
          analysisMode,
          winner,
          analysisModeName,
          analysisDimensionsText
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Comprehensive analysis stream server error:', {
          status: response.status,
          statusText: response.statusText,
          errorText
        });
        throw new Error(`Server error: ${response.status} - ${errorText}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let result: ComprehensiveAnalysisResult = { 
        conclusion: "基于当前分析维度，两份报告各有特色，需要进一步深入对比。",
        detailedAnalysis: "在当前分析框架下，两份报告在结构完整性、内容深度、数据质量和逻辑严密性等方面表现出不同的特点。建议结合具体业务场景和应用目标，进行更加细化的专项分析。"
      };
      
      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6);
              try {
                const parsed = JSON.parse(data);
                
                if (parsed.type === 'progress' && onProgress) {
                  onProgress(parsed.progress, parsed.message);
                } else if (parsed.type === 'token' && onToken) {
                  onToken(parsed.content, parsed.accumulated);
                } else if (parsed.type === 'complete') {
                  result = parsed.data;
                } else if (parsed.type === 'error') {
                  throw new Error(parsed.message);
                }
              } catch (e) {
                // 忽略解析错误
                console.warn('Parse error:', e);
              }
            }
          }
        }
      }
      
      console.log('Comprehensive analysis stream success:', result);
      return result;
    } catch (error) {
      console.error('Generate comprehensive analysis stream failed:', error);
      return {
        conclusion: "基于当前分析维度，两份报告各有特色，需要进一步深入对比。",
        detailedAnalysis: "在当前分析框架下，两份报告在结构完整性、内容深度、数据质量和逻辑严密性等方面表现出不同的特点。建议结合具体业务场景和应用目标，进行更加细化的专项分析。"
      };
    }
  }

  // 生成AI综合评估 - 原版本（保持向后兼容）
  async generateComprehensiveAnalysis(
    report1Content: string,
    report2Content: string,
    report1Title: string,
    report2Title: string,
    analysisMode: string,
    winner: string,
    analysisModeName?: string,
    analysisDimensionsText?: string
  ): Promise<ComprehensiveAnalysisResult> {
    console.log('=== Frontend: Calling generateComprehensiveAnalysis ===', {
      url: `${this.baseUrl}/ai/generate-comprehensive-analysis`,
      report1Title,
      report2Title,
      analysisMode,
      winner,
      analysisModeName,
      analysisDimensionsTextLength: analysisDimensionsText?.length || 0,
      report1ContentLength: report1Content?.length || 0,
      report2ContentLength: report2Content?.length || 0
    });
    
    try {
      const response = await fetch(`${this.baseUrl}/ai/generate-comprehensive-analysis`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          report1Content,
          report2Content,
          report1Title,
          report2Title,
          analysisMode,
          winner,
          analysisModeName,
          analysisDimensionsText
        })
      });

      console.log('Comprehensive analysis response:', {
        ok: response.ok,
        status: response.status,
        statusText: response.statusText
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Comprehensive analysis server error:', {
          status: response.status,
          statusText: response.statusText,
          errorText
        });
        throw new Error(`Server error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      console.log('Comprehensive analysis success:', data);
      return data;
    } catch (error) {
      console.error('Generate comprehensive analysis failed:', error);
      return {
        conclusion: "基于当前分析维度，两份报告各有特色，需要进一步深入对比。",
        detailedAnalysis: "在当前分析框架下，两份报告在结构完整性、内容深度、数据质量和逻辑严密性等方面表现出不同的特点。建议结合具体业务场景和应用目标，进行更加细化的专项分析。"
      };
    }
  }

  // 生成学习维度分析
  async generateLearningDimensions(
    currentReportContent: string,
    targetReportContent: string,
    currentReportTitle: string,
    targetReportTitle: string,
    analysisMode: string,
    isWinning: boolean,
    analysisModeName?: string,
    analysisDimensionsText?: string
  ): Promise<Record<string, string>> {
    try {
      const response = await fetch(`${this.baseUrl}/ai/generate-learning-dimensions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          currentReportContent,
          targetReportContent,
          currentReportTitle,
          targetReportTitle,
          analysisMode,
          isWinning,
          analysisModeName,
          analysisDimensionsText
        })
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Generate learning dimensions failed:', error);
      return {
        "内容完整性": "目标报告在内容完整性方面表现突出，值得学习借鉴。",
        "逻辑框架": "在逻辑框架方面表现突出，分析全面深入，专业性强。",
        "数据支撑": "数据处理规范专业，来源可靠，呈现清晰，为分析结论提供了有力支撑。",
        "实用价值": "在实用价值方面表现优秀，推理链条完整，结论得出自然。"
      };
    }
  }
}

export const openaiService = new OpenAIService();