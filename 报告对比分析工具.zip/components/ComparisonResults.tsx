import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { CheckCircle, AlertTriangle, Target, BarChart3, XCircle, Loader2 } from 'lucide-react';
import { Report, ComparisonResult } from './types';
import { openaiService } from '../utils/openai-service';

interface ComparisonResultsProps {
  result: ComparisonResult;
  reports: { report1: Report | null; report2: Report | null };
  analysisMode?: string;
  analysisModeInfo?: { id: string; name: string; prompt: string; };
}

interface DataComparisonRow {
  category: string;
  report1Value?: string;
  report2Value?: string;
  status: 'correct' | 'suspicious' | 'missing';
  suggestion: string;
}

export function ComparisonResults({ result, reports, analysisMode = 'comprehensive', analysisModeInfo }: ComparisonResultsProps) {
  
  // 获取分析重点详情
  const getAnalysisPromptDetails = (mode: string): string => {
    const detailMap: Record<string, string> = {
      comprehensive: '- 内容完整性：信息覆盖面、关键要素缺漏、论述深度差异\n- 逻辑框架：结构合理性、论证链条完整性、因果关系清晰度\n- 数据支撑：量化证据充分性、数据可信度、图表有效性\n- 实用价值：决策支持力度、可操作性建议、预期效果评估',
      data: '- 数据来源：权威性、时效性、覆盖范围、样本代表性\n- 数据质量：准确性、完整性、一致性、异常值处理\n- 分析方法：统计模型选择、计算逻辑、趋势预测合理性\n- 可视化效果：图表类型适配性、信息传达清晰度、视觉冲击力\n- 结论支撑：数据与观点匹配度、推论严谨性',
      business: '- 战略洞察：市场趋势把握、竞争态势分析、机会识别精准度\n- 风险评估：潜在威胁预警、风险量化程度、应对策略完备性\n- 执行指导：行动方案具体性、资源配置建议、时间节点规划\n- ROI分析：投入产出预期、成本效益评估、财务影响量化\n- 决策支持：关键问题解答、多情景预案、KPI设定',
      structure: '- 整体架构：信息层次设计、章节逻辑关系、内容流转顺畅度\n- 论证体系：观点提出顺序、证据支撑链条、反驳预期处理\n- 表达技巧：语言准确性、专业术语使用、读者理解友好度\n- 格式规范：标题体系、段落结构、视觉呈现一致性\n- 阅读体验：信息检索便利性、重点突出效果、记忆点设置',
      research: '- 方法论：研究设计科学性、调研方法适配性、样本选择合理性、变量控制有效性\n- 创新价值：观点原创性、理论贡献度、实践启发性、行业突破性\n- 文献基础：引用权威性、理论溯源完整性、前沿动态把握、知识体系构建\n- 验证严谨性：假设检验充分性、结论推导逻辑性、局限性坦诚度\n- 学术影响：可复制性、可推广性、后续研究价值'
    };
    return detailMap[mode] || detailMap.comprehensive;
  };
  const [dataComparison, setDataComparison] = useState<DataComparisonRow[]>([]);
  const [aiAnalysis, setAiAnalysis] = useState({ conclusion: '', detailedAnalysis: '' });
  const [loading, setLoading] = useState(true);
  
  // 缓存机制
  const [analysisCache, setAnalysisCache] = useState<Record<string, {
    dataComparison: DataComparisonRow[];
    aiAnalysis: { conclusion: string; detailedAnalysis: string };
  }>>({});
  // 初始化数据对比和AI分析
  useEffect(() => {
    const initializeAnalysis = async () => {
      if (!reports.report1 || !reports.report2) return;

      // 简化缓存键生成
      const cacheKey = `${reports.report1.title.substring(0, 10)}-${reports.report2.title.substring(0, 10)}-${analysisMode}`;
      
      // 检查缓存
      if (analysisCache[cacheKey]) {
        console.log('Using cached ComparisonResults data:', cacheKey);
        setDataComparison(analysisCache[cacheKey].dataComparison);
        setAiAnalysis(analysisCache[cacheKey].aiAnalysis);
        setLoading(false);
        return;
      }

      console.log('Generating new ComparisonResults data...', { cacheKey });
      setLoading(true);
      try {
        // 1. 提取数据点
        const dataPoints = await openaiService.extractDataPoints(
          reports.report1.content,
          reports.report2.content,
          reports.report1.title,
          reports.report2.title
        );

        // 2. 生成数据对比表格
        const comparisonRows: DataComparisonRow[] = [];
        
        for (const category of dataPoints.unionCategories) {
          const report1Data = dataPoints.report1DataPoints.find(dp => dp.category === category);
          const report2Data = dataPoints.report2DataPoints.find(dp => dp.category === category);
          
          let status: 'correct' | 'suspicious' | 'missing';
          if (!report1Data && !report2Data) {
            continue; // 跳过两边都没有的数据
          } else if (!report1Data || !report2Data) {
            status = 'missing';
          } else if (report1Data.value === report2Data.value) {
            status = 'correct';
          } else {
            status = 'suspicious';
          }
          
          // 生成AI建议
          const suggestion = await openaiService.generateDataValidationSuggestion(
            category,
            report1Data?.value,
            report2Data?.value,
            status
          );
          
          comparisonRows.push({
            category,
            report1Value: report1Data?.value,
            report2Value: report2Data?.value,
            status,
            suggestion
          });
        }

        setDataComparison(comparisonRows);

        // 3. 生成AI综合评估
        const analysis = await openaiService.generateComprehensiveAnalysis(
          reports.report1.content,
          reports.report2.content,
          reports.report1.title,
          reports.report2.title,
          analysisMode,
          result.winner,
          analysisModeInfo?.name || '综合对比',
          getAnalysisPromptDetails(analysisMode)
        );

        setAiAnalysis(analysis);
        
        // 缓存结果，使用同样的缓存键
        setAnalysisCache(prev => ({
          ...prev,
          [cacheKey]: {
            dataComparison: comparisonRows,
            aiAnalysis: analysis
          }
        }));
        
        console.log('ComparisonResults data generated and cached');
      } catch (error) {
        console.error('Analysis initialization failed:', error);
        // 提供默认数据
        setDataComparison([
          { 
            category: '营收数据', 
            report1Value: '1250万元', 
            report2Value: undefined, 
            status: 'missing', 
            suggestion: '数据缺失，建议补充相关财务数据' 
          }
        ]);
        const fallbackAnalysis = {
          conclusion: "基于当前分析维度，两份报告各有特色，需要进一步深入对比。",
          detailedAnalysis: "建议结合具体业务场景进行更细化的专项分析。"
        };
        setAiAnalysis(fallbackAnalysis);
        
        // 缓存错误情况的默认结果，使用同样的缓存键
        setAnalysisCache(prev => ({
          ...prev,
          [cacheKey]: {
            dataComparison: [
              { 
                category: '营收数据', 
                report1Value: '1250万元', 
                report2Value: undefined, 
                status: 'missing', 
                suggestion: '数据缺失，建议补充相关财务数据' 
              }
            ],
            aiAnalysis: fallbackAnalysis
          }
        }));
      } finally {
        setLoading(false);
      }
    };

    initializeAnalysis();
  }, [reports, analysisMode, result.winner]);

  const getComparisonText = () => {
    if (result.winner === 'tie') return `${reports.report1?.title || '报告 1'} = ${reports.report2?.title || '报告 2'}`;
    if (result.winner === 'report1') return `${reports.report1?.title || '报告 1'} > ${reports.report2?.title || '报告 2'}`;
    return `${reports.report2?.title || '报告 2'} > ${reports.report1?.title || '报告 1'}`;
  };

  const getDataStatusIcon = (status: string) => {
    switch (status) {
      case 'correct': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'suspicious': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'missing': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <AlertTriangle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getDataStatusText = (status: string) => {
    switch (status) {
      case 'correct': return '数据一致';
      case 'suspicious': return '数据存疑';
      case 'missing': return '数据缺失';
      default: return '未验证';
    }
  };

  return (
    <div className="space-y-6">
      {/* 置顶判定结果 */}
      <Card className="border-2 border-blue-200 bg-blue-50/50">
        <CardContent className="pt-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900">
              {getComparisonText()}
            </h2>
          </div>
        </CardContent>
      </Card>

      {/* 第一层：硬性指标 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            第一层对比：硬性指标
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* 字数对比 */}
          <div>
            <h4 className="font-medium mb-3">字数对比</h4>
            <div className="grid md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="text-center">
                <div className="text-sm text-gray-600 mb-1">{reports.report1?.title || '报告 1'}</div>
                <div className="text-2xl font-bold text-blue-600">
                  {result.metrics.wordCount.report1.toLocaleString()}
                </div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600 mb-1">{reports.report2?.title || '报告 2'}</div>
                <div className="text-2xl font-bold text-green-600">
                  {result.metrics.wordCount.report2.toLocaleString()}
                </div>
              </div>
              <div className="text-center">
                <div className="text-xs text-gray-500 mb-1">
                  {result.metrics.wordCount.difference > 0 
                    ? `${reports.report1?.title}比${reports.report2?.title}长${result.metrics.wordCount.percentage.toFixed(1)}%`
                    : `${reports.report2?.title}比${reports.report1?.title}长${result.metrics.wordCount.percentage.toFixed(1)}%`
                  }
                </div>
                <div className="text-2xl font-bold text-gray-900">
                  {result.metrics.wordCount.percentage.toFixed(1)}%
                </div>
              </div>
            </div>
          </div>

          {/* 数据验证对比表格 */}
          <div>
            <h4 className="font-medium mb-3">数据验证对比</h4>
            {loading ? (
              <div className="flex items-center justify-center p-8">
                <Loader2 className="h-6 w-6 animate-spin mr-2" />
                <span>正在分析数据点...</span>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>数据项</TableHead>
                    <TableHead className="text-center">{reports.report1?.title || '报告 1'}</TableHead>
                    <TableHead className="text-center">{reports.report2?.title || '报告 2'}</TableHead>
                    <TableHead className="text-center">验证状态</TableHead>
                    <TableHead>AI建议</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dataComparison.map((row, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{row.category}</TableCell>
                      <TableCell className="text-center">
                        {row.report1Value ? (
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            {row.report1Value}
                          </Badge>
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        {row.report2Value ? (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            {row.report2Value}
                          </Badge>
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-2">
                          {getDataStatusIcon(row.status)}
                          <span className="text-xs">{getDataStatusText(row.status)}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {row.suggestion}
                      </TableCell>
                    </TableRow>
                  ))}
                  {dataComparison.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-gray-500 py-8">
                        暂未检测到可对比的数据点
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 第二层：AI综合分析 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            第二层分析：{analysisModeInfo?.name || 'AI综合评估'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {loading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-6 w-6 animate-spin mr-2" />
              <span>正在生成AI综合评估...</span>
            </div>
          ) : (
            <>
              {/* 结论 */}
              <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                <p className="text-blue-800 font-medium">{aiAnalysis.conclusion}</p>
              </div>

              {/* 详细分析 */}
              <div className="p-4 bg-gray-50 rounded-lg">
                <h4 className="font-medium mb-3">{analysisModeInfo?.name || '综合对比'}</h4>
                <div 
                  className="text-gray-700 leading-relaxed whitespace-pre-wrap"
                  style={{ 
                    whiteSpace: 'pre-wrap',
                    lineHeight: '1.6'
                  }}
                  dangerouslySetInnerHTML={{
                    __html: aiAnalysis.detailedAnalysis
                      .replace(/###\s+(.+)/g, '<h4 style="font-weight: 600; margin: 16px 0 8px 0; color: #1f2937;">$1</h4>')
                      .replace(/\n/g, '<br/>')
                  }}
                />
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}