import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Star } from 'lucide-react';
import { AdvantageItem } from './types';

interface AdvantagesSectionProps {
  advantages: AdvantageItem[];
}

export function AdvantagesSection({ advantages }: AdvantagesSectionProps) {
  if (advantages.length === 0) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-green-600">
          <Star className="h-5 w-5" />
          当前优势
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {advantages.map((advantage, index) => (
            <div key={index} className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
              <div className="text-green-600 mt-0.5">
                {advantage.icon}
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-green-800">{advantage.title}</h4>
                <p className="text-sm text-green-700 mt-1">{advantage.description}</p>
                <Badge variant="outline" className="mt-2 border-green-300 text-green-700">
                  {advantage.impact === 'high' ? '重要优势' : advantage.impact === 'medium' ? '一般优势' : '轻微优势'}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}