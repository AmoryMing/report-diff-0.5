import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Upload, FileText, Hash } from 'lucide-react';

interface Report {
  id: string;
  title: string;
  content: string;
  wordCount: number;
}

interface ReportInputProps {
  reportId: 'report1' | 'report2';
  title: string;
  onReportUpdate: (reportId: 'report1' | 'report2', report: Report) => void;
}

export function ReportInput({ reportId, title, onReportUpdate }: ReportInputProps) {
  const [reportTitle, setReportTitle] = useState('');
  const [content, setContent] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleContentChange = (value: string) => {
    setContent(value);
    
    // 实时更新报告信息
    if (value.trim()) {
      const report: Report = {
        id: reportId,
        title: reportTitle || `${title}（未命名）`,
        content: value,
        wordCount: value.length
      };
      onReportUpdate(reportId, report);
    }
  };

  const handleTitleChange = (value: string) => {
    setReportTitle(value);
    
    // 如果已有内容，更新报告信息
    if (content.trim()) {
      const report: Report = {
        id: reportId,
        title: value || `${title}（未命名）`,
        content: content,
        wordCount: content.length
      };
      onReportUpdate(reportId, report);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setContent(text);
      setReportTitle(file.name.split('.')[0]);
      
      const report: Report = {
        id: reportId,
        title: file.name.split('.')[0],
        content: text,
        wordCount: text.length
      };
      onReportUpdate(reportId, report);
      setIsProcessing(false);
    };
    
    reader.readAsText(file);
  };

  const loadSampleData = () => {
    const sampleData = reportId === 'report1' ? {
      title: '2024年市场分析报告',
      content: `一、市场概况
本季度市场整体表现良好，主要指标如下：
- 总营收：1250万元，同比增长15.3%
- 市场份额：23.8%，较上季度提升2.1个百分点
- 客户满意度：87.5%，达到历史新高

二、主要发现
1. 数字化转型驱动业务增长
   通过技术升级，运营效率提升了18.7%，为企业带来显著价值。

2. 新兴市场表现突出
   三四线城市销售额增长了42.3%，成为新的增长引擎。

3. 产品创新获得认可
   新产品线贡献了28.4%的总收入，市场接受度超出预期。

三、风险分析
- 原材料成本上涨压力
- 竞争对手价格战策略
- 宏观经济不确定性

四、建议与展望
建议加强供应链管理，优化成本结构，同时加大研发投入，保持产品领先优势。`
    } : {
      title: '业务运营季度总结',
      content: `运营数据概览
本季度各项运营指标稳中有升：

核心指标：
• 活跃用户数：890万，环比增长8.2%
• 用户留存率：72.1%，同比提升5.4%
• 平台GMV：4.2亿元，创历史新高

业务亮点：
1. 移动端表现优异
   - 移动端流量占比达78.3%
   - 移动支付转化率提升至91.7%
   - APP日活用户突破450万

2. 客户服务水平提升
   - 响应时间缩短至2.3分钟
   - 问题解决率达96.8%
   - NPS得分提升至73

3. 运营效率持续优化
   - 订单处理时效提升35%
   - 库存周转率达到4.2次/月
   - 综合成本下降12.7%

挑战与机遇：
当前面临获客成本上升、市场竞争加剧等挑战，但新技术应用和用户体验优化为未来发展提供了机遇。

下阶段重点：
专注提升用户体验，扩大市场份额，完善运营体系。`
    };
    
    setReportTitle(sampleData.title);
    setContent(sampleData.content);
    
    const report: Report = {
      id: reportId,
      title: sampleData.title,
      content: sampleData.content,
      wordCount: sampleData.content.length
    };
    onReportUpdate(reportId, report);
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          <Input
            placeholder={`${title}标题`}
            value={reportTitle}
            onChange={(e) => handleTitleChange(e.target.value)}
            className="border-none bg-transparent p-0 text-lg font-semibold focus-visible:ring-0 focus-visible:ring-offset-0"
          />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">

        {/* 文件上传 */}
        <div className="space-y-2">
          <Label>导入文件</Label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="file"
                accept=".txt,.md,.doc,.docx"
                onChange={handleFileUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                disabled={isProcessing}
              />
              <Button
                variant="outline"
                disabled={isProcessing}
                className="w-full"
              >
                <Upload className="h-4 w-4 mr-2" />
                {isProcessing ? '处理中...' : '上传文件'}
              </Button>
            </div>
            <Button
              variant="outline"
              onClick={loadSampleData}
              className="whitespace-nowrap"
            >
              加载示例
            </Button>
          </div>
        </div>

        {/* 报告内容 */}
        <div className="space-y-2">
          <Label htmlFor={`content-${reportId}`}>报告内容</Label>
          <Textarea
            id={`content-${reportId}`}
            placeholder="请输入或粘贴报告内容..."
            value={content}
            onChange={(e) => handleContentChange(e.target.value)}
            className="min-h-[300px] resize-y"
          />
        </div>

        {/* 统计信息 */}
        {content && (
          <div className="flex items-center gap-4 text-sm text-gray-500 bg-gray-50 p-3 rounded-lg">
            <div className="flex items-center gap-1">
              <Hash className="h-4 w-4" />
              字数：{content.length}
            </div>
            <div>
              段落：{content.split('\n').filter(line => line.trim()).length}
            </div>
            <div>
              数据点：{(content.match(/\d+/g) || []).length}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}