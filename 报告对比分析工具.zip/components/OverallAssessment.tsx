import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { CheckCircle, AlertCircle, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Report } from './types';
import { getScoreColor, getScoreBg } from './optimization-utils';

interface OverallAssessmentProps {
  currentReport: Report | null;
  overallScore: number;
  isWinning: boolean;
}

export function OverallAssessment({ currentReport, overallScore, isWinning }: OverallAssessmentProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {isWinning ? <ThumbsUp className="h-5 w-5 text-green-600" /> : <ThumbsDown className="h-5 w-5 text-orange-600" />}
          《{currentReport?.title}》总体评估
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className={`p-4 rounded-lg ${getScoreBg(overallScore)}`}>
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">综合得分</span>
              <span className={`text-2xl font-bold ${getScoreColor(overallScore)}`}>
                {overallScore.toFixed(1)}
              </span>
            </div>
            <Progress value={overallScore} className="h-2" />
          </div>
          
          {isWinning ? (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>优势明显</strong> - 当前报告在综合评估中表现更佳，可进一步融合对方报告的优势元素。
              </AlertDescription>
            </Alert>
          ) : (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>有提升空间</strong> - 建议学习对方报告的优秀做法，重点改进薄弱环节。
              </AlertDescription>
            </Alert>
          )}
        </div>
      </CardContent>
    </Card>
  );
}