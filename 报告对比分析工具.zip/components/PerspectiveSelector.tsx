import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Report, ComparisonResult } from './types';

interface PerspectiveSelectorProps {
  reports: { report1: Report | null; report2: Report | null };
  result: ComparisonResult;
  selectedPerspective: 'report1' | 'report2';
  onPerspectiveChange: (perspective: 'report1' | 'report2') => void;
}

export function PerspectiveSelector({
  reports,
  result,
  selectedPerspective,
  onPerspectiveChange
}: PerspectiveSelectorProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>选择分析视角</CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup
          value={selectedPerspective}
          onValueChange={(value: 'report1' | 'report2') => onPerspectiveChange(value)}
          className="grid md:grid-cols-2 gap-4"
        >
          <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
            <RadioGroupItem value="report1" id="report1" />
            <Label htmlFor="report1" className="flex-1 cursor-pointer">
              <div>
                <div className="font-medium">{reports.report1?.title || '报告 1'}</div>
                <div className="text-sm text-gray-500">
                  {reports.report1?.wordCount} 字 · {result.metrics.dataValidation.filter(v => v.source === 'report1' || v.source === 'both').length} 个数据点
                </div>
              </div>
            </Label>
          </div>
          <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
            <RadioGroupItem value="report2" id="report2" />
            <Label htmlFor="report2" className="flex-1 cursor-pointer">
              <div>
                <div className="font-medium">{reports.report2?.title || '报告 2'}</div>
                <div className="text-sm text-gray-500">
                  {reports.report2?.wordCount} 字 · {result.metrics.dataValidation.filter(v => v.source === 'report2' || v.source === 'both').length} 个数据点
                </div>
              </div>
            </Label>
          </div>
        </RadioGroup>
      </CardContent>
    </Card>
  );
}