import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ArrowRight, Lightbulb } from 'lucide-react';
import { ImprovementItem } from './types';

interface ImprovementsSectionProps {
  improvements: ImprovementItem[];
}

export function ImprovementsSection({ improvements }: ImprovementsSectionProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-orange-600">
          <Lightbulb className="h-5 w-5" />
          优化建议
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {improvements.map((improvement, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex items-start gap-3 mb-3">
                <div className="text-orange-600 mt-0.5">
                  {improvement.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium">{improvement.title}</h4>
                    <Badge variant={improvement.priority === 'high' ? 'destructive' : 'secondary'}>
                      {improvement.priority === 'high' ? '高优先级' : improvement.priority === 'medium' ? '中优先级' : '低优先级'}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{improvement.description}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <h5 className="text-sm font-medium text-gray-700">具体行动：</h5>
                <ul className="space-y-1">
                  {improvement.actions.map((action, actionIndex) => (
                    <li key={actionIndex} className="flex items-center gap-2 text-sm">
                      <ArrowRight className="h-3 w-3 text-gray-400" />
                      <span>{action}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}