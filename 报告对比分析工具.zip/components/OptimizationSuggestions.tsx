import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Target, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { Report, ComparisonResult } from './types';
import { openaiService } from '../utils/openai-service';

interface OptimizationSuggestionsProps {
  result: ComparisonResult;
  reports: { report1: Report | null; report2: Report | null };
  selectedPerspective: 'report1' | 'report2';
  onPerspectiveChange: (perspective: 'report1' | 'report2') => void;
  analysisMode?: string;
  analysisModeInfo?: { id: string; name: string; prompt: string; };
}

export function OptimizationSuggestions({
  result,
  reports,
  selectedPerspective,
  onPerspectiveChange,
  analysisMode = 'comprehensive',
  analysisModeInfo
}: OptimizationSuggestionsProps) {
  
  // 获取分析重点详情
  const getAnalysisPromptDetails = (mode: string): string => {
    const detailMap: Record<string, string> = {
      comprehensive: '- 内容完整性：信息覆盖面、关键要素缺漏、论述深度差异\n- 逻辑框架：结构合理性、论证链条完整性、因果关系清晰度\n- 数据支撑：量化证据充分性、数据可信度、图表有效性\n- 实用价值：决策支持力度、可操作性建议、预期效果评估',
      data: '- 数据来源：权威性、时效性、覆盖范围、样本代表性\n- 数据质量：准确性、完整性、一致性、异常值处理\n- 分析方法：统计模型选择、计算逻辑、趋势预测合理性\n- 可视化效果：图表类型适配性、信息传达清晰度、视觉冲击力\n- 结论支撑：数据与观点匹配度、推论严谨性',
      business: '- 战略洞察：市场趋势把握、竞争态势分析、机会识别精准度\n- 风险评估：潜在威胁预警、风险量化程度、应对策略完备性\n- 执行指导：行动方案具体性、资源配置建议、时间节点规划\n- ROI分析：投入产出预期、成本效益评估、财务影响量化\n- 决策支持：关键问题解答、多情景预案、KPI设定',
      structure: '- 整体架构：信息层次设计、章节逻辑关系、内容流转顺畅度\n- 论证体系：观点提出顺序、证据支撑链条、反驳预期处理\n- 表达技巧：语言准确性、专业术语使用、读者理解友好度\n- 格式规范：标题体系、段落结构、视觉呈现一致性\n- 阅读体验：信息检索便利性、重点突出效果、记忆点设置',
      research: '- 方法论：研究设计科学性、调研方法适配性、样本选择合理性、变量控制有效性\n- 创新价值：观点原创性、理论贡献度、实践启发性、行业突破性\n- 文献基础：引用权威性、理论溯源完整性、前沿动态把握、知识体系构建\n- 验证严谨性：假设检验充分性、结论推导逻辑性、局限性坦诚度\n- 学术影响：可复制性、可推广性、后续研究价值'
    };
    return detailMap[mode] || detailMap.comprehensive;
  };

  const currentReport = reports[selectedPerspective];
  const otherReport = reports[selectedPerspective === 'report1' ? 'report2' : 'report1'];
  const isWinning = result.winner === selectedPerspective;

  const [aiSummary, setAiSummary] = useState<string>('');
  const [actionItems, setActionItems] = useState<string[]>([]);
  const [learningDimensions, setLearningDimensions] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  
  // 简化缓存机制
  const [suggestionCache, setSuggestionCache] = useState<Record<string, {
    aiSummary: string;
    actionItems: string[];
    learningDimensions: Record<string, string>;
  }>>({});

  // AI 动态生成内容
  useEffect(() => {
    const generateContent = async () => {
      if (!currentReport || !otherReport) return;

      // 生成缓存键
      const cacheKey = `${currentReport.title.substring(0, 10)}-${otherReport.title.substring(0, 10)}-${analysisMode}-${selectedPerspective}`;
      
      // 检查缓存
      if (suggestionCache[cacheKey]) {
        console.log('Using cached OptimizationSuggestions data:', cacheKey);
        setAiSummary(suggestionCache[cacheKey].aiSummary);
        setActionItems(suggestionCache[cacheKey].actionItems);
        setLearningDimensions(suggestionCache[cacheKey].learningDimensions);
        setLoading(false);
        return;
      }

      console.log('Generating new OptimizationSuggestions data...', { cacheKey });
      setLoading(true);
      try {
        // 生成一句话总结
        const summary = await openaiService.generateOptimizationSummary(
          currentReport.title,
          otherReport.title,
          isWinning,
          getAnalysisTypeText(analysisMode)
        );

        // 收集学习要点
        const learningPoints = [
          result.analysis.dimensions.structure.analysis,
          result.analysis.dimensions.content.analysis,
          result.analysis.dimensions.dataQuality.analysis,
          result.analysis.dimensions.logic.analysis
        ];

        // 生成具体执行项
        const actions = await openaiService.generateActionItems(
          currentReport.title,
          otherReport.title,
          isWinning,
          getAnalysisTypeText(analysisMode),
          learningPoints
        );

        // 生成学习维度分析
        const dimensions = await openaiService.generateLearningDimensions(
          currentReport.content,
          otherReport.content,
          currentReport.title,
          otherReport.title,
          analysisMode,
          isWinning,
          analysisModeInfo?.name || '综合对比',
          getAnalysisPromptDetails(analysisMode)
        );

        setAiSummary(summary);
        setActionItems(actions);
        setLearningDimensions(dimensions);
        
        // 缓存结果
        setSuggestionCache(prev => ({
          ...prev,
          [cacheKey]: {
            aiSummary: summary,
            actionItems: actions,
            learningDimensions: dimensions
          }
        }));
      } catch (error) {
        console.error('AI generation failed:', error);
        // 提供备用静态内容
        const fallbackSummary = isWinning 
          ? `《${currentReport?.title}》在${getAnalysisTypeText(analysisMode)}方面表现优异，但仍可从对方经验中进一步优化。`
          : `《${currentReport?.title}》在${getAnalysisTypeText(analysisMode)}方面有明显提升空间，应重点学习对方的优秀做法。`;
        
        const fallbackActions = [
          '分析对方报告的核心优势点',
          '识别自身报告的薄弱环节',
          '制定具体的改进计划',
          '逐步实施优化措施'
        ];
        
        // 提供默认的动态维度，基于当前分析模式
        const fallbackDimensions: Record<string, string> = {};
        const analysisDetails = getAnalysisPromptDetails(analysisMode);
        const dimensionLines = analysisDetails.split('\n');
        dimensionLines.forEach((line, index) => {
          const dimensionName = line.split('：')[0].replace('- ', '');
          fallbackDimensions[dimensionName] = `目标报告在${dimensionName}方面表现突出，值得学习借鉴。`;
        });
        
        setAiSummary(fallbackSummary);
        setActionItems(fallbackActions);
        setLearningDimensions(fallbackDimensions);
        
        // 缓存错误情况的默认结果
        setSuggestionCache(prev => ({
          ...prev,
          [cacheKey]: {
            aiSummary: fallbackSummary,
            actionItems: fallbackActions,
            learningDimensions: fallbackDimensions
          }
        }));
      } finally {
        setLoading(false);
      }
    };

    generateContent();
  }, [currentReport, otherReport, isWinning, analysisMode, result]);

  const getAnalysisTypeText = (mode: string) => {
    const typeMap: Record<string, string> = {
      comprehensive: '综合分析',
      data: '数据分析',
      business: '商业价值',
      structure: '结构逻辑',
      research: '研究深度'
    };
    return typeMap[mode] || '综合分析';
  };

  const assessment = {
    type: isWinning ? 'success' : 'improvement',
    title: isWinning ? '优势明显' : '有提升空间',
    description: loading ? '正在生成AI分析...' : aiSummary
  };

  return (
    <div className="space-y-6">
      {/* 视角选择 */}
      <Card>
        <CardHeader>
          <CardTitle>选择分析视角</CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={selectedPerspective}
            onValueChange={(value: 'report1' | 'report2') => onPerspectiveChange(value)}
            className="grid md:grid-cols-2 gap-4"
          >
            <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
              <RadioGroupItem value="report1" id="report1" />
              <Label htmlFor="report1" className="flex-1 cursor-pointer">
                <div>
                  <div className="font-medium">{reports.report1?.title || '报告 1'}</div>
                  <div className="text-sm text-gray-500">
                    {reports.report1?.wordCount} 字
                  </div>
                </div>
              </Label>
            </div>
            <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
              <RadioGroupItem value="report2" id="report2" />
              <Label htmlFor="report2" className="flex-1 cursor-pointer">
                <div>
                  <div className="font-medium">{reports.report2?.title || '报告 2'}</div>
                  <div className="text-sm text-gray-500">
                    {reports.report2?.wordCount} 字
                  </div>
                </div>
              </Label>
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      {/* AI 动态评估 */}
      <Alert>
        {loading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : assessment.type === 'success' ? (
          <CheckCircle className="h-4 w-4" />
        ) : (
          <AlertCircle className="h-4 w-4" />
        )}
        <AlertDescription>
          <div className="space-y-2">
            <strong>{assessment.title}</strong>
            <p className="text-sm">{assessment.description}</p>
          </div>
        </AlertDescription>
      </Alert>

      {/* 学习要点 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-600">
            <Target className="h-5 w-5" />
            向《{otherReport?.title}》学习
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {loading ? (
              <div className="flex items-center justify-center p-8">
                <Loader2 className="h-6 w-6 animate-spin mr-2" />
                <span>正在生成学习要点...</span>
              </div>
            ) : (
              <>
                <div className="space-y-4">
                  {Object.entries(learningDimensions).map(([dimension, analysis]) => (
                    <div key={dimension} className="space-y-2">
                      <h4 className="font-medium">{dimension}</h4>
                      <p className="text-sm text-gray-600">{analysis}</p>
                    </div>
                  ))}
                </div>
              </>
            )}
            
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-800 mb-3">融合建议</h4>
              {loading ? (
                <div className="flex items-center gap-2 text-blue-700">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span className="text-sm">正在生成具体执行项...</span>
                </div>
              ) : (
                <ul className="space-y-2">
                  {actionItems.map((item, index) => (
                    <li key={index} className="text-sm text-blue-700 flex items-start gap-2">
                      <span className="flex-shrink-0 w-5 h-5 bg-blue-200 text-blue-800 rounded-full text-xs flex items-center justify-center mt-0.5">
                        {index + 1}
                      </span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}