import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Target } from 'lucide-react';
import { Report, ComparisonResult } from './types';

interface LearningPointsProps {
  otherReport: Report | null;
  result: ComparisonResult;
  isWinning: boolean;
}

export function LearningPoints({ otherReport, result, isWinning }: LearningPointsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-blue-600">
          <Target className="h-5 w-5" />
          向《{otherReport?.title}》学习
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium">结构特点</h4>
              <p className="text-sm text-gray-600">
                {result.analysis.dimensions.structure.analysis}
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium">内容优势</h4>
              <p className="text-sm text-gray-600">
                {result.analysis.dimensions.content.analysis}
              </p>
            </div>
          </div>
          
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">融合建议</h4>
            <p className="text-sm text-blue-700">
              {isWinning 
                ? '在保持当前优势的基础上，可以借鉴对方报告在薄弱维度的优秀做法，进一步提升报告的综合质量。'
                : '重点学习对方报告的核心优势，特别是在数据质量、结构框架、逻辑推理和内容深度方面的优秀实践，快速提升报告价值。'
              }
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}