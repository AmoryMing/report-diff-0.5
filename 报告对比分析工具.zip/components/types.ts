export interface Report {
  id: string;
  title: string;
  content: string;
  wordCount: number;
}

export interface DataValidation {
  value: string;
  source: 'report1' | 'report2' | 'both';
  status: 'correct' | 'suspicious' | 'conflicting';
  suggestion?: string;
}

export interface ComparisonResult {
  // 总体判定
  overallDifference: number; // 差异百分比
  winner: 'report1' | 'report2' | 'tie';
  confidenceLevel: 'high' | 'medium' | 'low';
  
  // 第一层：硬性指标
  metrics: {
    wordCount: { report1: number; report2: number; difference: number; percentage: number };
    dataValidation: DataValidation[];
  };
  
  // 第二层：AI综合分析
  analysis: {
    conclusion: string; // 一句话结论
    detailedAnalysis: string; // 大模型一段话分析
    dimensions: {
      dataQuality: { report1: number; report2: number; analysis: string };
      structure: { report1: number; report2: number; analysis: string };
      logic: { report1: number; report2: number; analysis: string };
      content: { report1: number; report2: number; analysis: string };
    };
  };
}

export interface AdvantageItem {
  icon: React.ReactNode;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
}

export interface ImprovementItem {
  icon: React.ReactNode;
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  actions: string[];
}

export interface MetricsComparison {
  dataQuality: number;
  structure: number;
  logic: number;
  content: number;
  wordCount: number;
  dataValidationCount: number;
}