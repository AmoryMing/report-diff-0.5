import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { FileText, BarChart3, Briefcase, Target, BookOpen } from 'lucide-react';

interface PromptDebuggerProps {
  customPrompt: string;
  onPromptChange: (analysis: { id: string; name: string; prompt: string; }) => void;
}

export function PromptDebugger({ customPrompt, onPromptChange }: PromptDebuggerProps) {
  const [selectedTemplate, setSelectedTemplate] = useState('comprehensive');

  const analysisTemplates = [
    {
      id: 'comprehensive',
      name: '综合对比',
      icon: <FileText className="h-4 w-4" />,
      description: '全面分析内容质量、结构逻辑和决策价值',
      prompt: '作为专业分析师，请全面对比这两份报告的综合质量。重点分析：1）内容完整性：信息覆盖面、关键要素缺漏、论述深度差异；2）逻辑框架：结构合理性、论证链条完整性、因果关系清晰度；3）数据支撑：量化证据充分性、数据可信度、图表有效性；4）实用价值：决策支持力度、可操作性建议、预期效果评估。请提供具体的优劣势对比和改进建议。'
    },
    {
      id: 'data',
      name: '数据对比',
      icon: <BarChart3 className="h-4 w-4" />,
      description: '重点分析数据质量、准确性和说服力',
      prompt: '作为数据分析专家，请专门从数据角度深度对比这两份报告。核心评估维度：1）数据来源：权威性、时效性、覆盖范围、样本代表性；2）数据质量：准确性、完整性、一致性、异常值处理；3）分析方法：统计模型选择、计算逻辑、趋势预测合理性；4）可视化效果：图表类型适配性、信息传达清晰度、视觉冲击力；5）结论支撑：数据与观点匹配度、推论严谨性。请识别数据盲点并提出验证建议。'
    },
    {
      id: 'business',
      name: '商业价值',
      icon: <Briefcase className="h-4 w-4" />,
      description: '从商业决策角度评估报告价值',
      prompt: '作为商业顾问，请从企业决策制定角度对比评估这两份报告的商业价值。关键评估点：1）战略洞察：市场趋势把握、竞争态势分析、机会识别精准度；2）风险评估：潜在威胁预警、风险量化程度、应对策略完备性；3）执行指导：行动方案具体性、资源配置建议、时间节点规划；4）ROI分析：投入产出预期、成本效益评估、财务影响量化；5）决策支持：关键问题解答、多情景预案、KPI设定。请评估哪份报告更能指导实际商业行动。'
    },
    {
      id: 'structure',
      name: '结构逻辑',
      icon: <Target className="h-4 w-4" />,
      description: '分析报告架构、逻辑性和表达效果',
      prompt: '作为文档架构师，请专门从结构逻辑角度对比这两份报告的组织效果。深度分析：1）整体架构：信息层次设计、章节逻辑关系、内容流转顺畅度；2）论证体系：观点提出顺序、证据支撑链条、反驳预期处理；3）表达技巧：语言准确性、专业术语使用、读者理解友好度；4）格式规范：标题体系、段落结构、视觉呈现一致性；5）阅读体验：信息检索便利性、重点突出效果、记忆点设置。评估哪份报告的结构更有利于信息传达和说服效果。'
    },
    {
      id: 'research',
      name: '研究深度',
      icon: <BookOpen className="h-4 w-4" />,
      description: '评估研究方法、创新观点和学术价值',
      prompt: '作为研究方法专家，请从学术研究角度深度对比这两份报告的研究质量。专业评估维度：1）方法论：研究设计科学性、调研方法适配性、样本选择合理性、变量控制有效性；2）创新价值：观点原创性、理论贡献度、实践启发性、行业突破性；3）文献基础：引用权威性、理论溯源完整性、前沿动态把握、知识体系构建；4）验证严谨性：假设检验充分性、结论推导逻辑性、局限性坦诚度；5）学术影响：可复制性、可推广性、后续研究价值。请评估哪份报告具有更高的研究水准和学术贡献。'
    }
  ];

  const handleTemplateSelect = (template: typeof analysisTemplates[0]) => {
    setSelectedTemplate(template.id);
    onPromptChange({
      id: template.id,
      name: template.name,
      prompt: template.prompt
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>选择分析模式</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {analysisTemplates.map((template) => (
            <Button
              key={template.id}
              variant={selectedTemplate === template.id ? "default" : "outline"}
              className="h-auto p-4 flex flex-col items-start gap-2 text-left"
              onClick={() => handleTemplateSelect(template)}
            >
              <div className="flex items-center gap-2 w-full">
                {template.icon}
                <span className="font-medium">{template.name}</span>
              </div>
              <p className="text-xs text-gray-600 leading-relaxed">
                {template.description}
              </p>
            </Button>
          ))}
        </div>
        
        {/* 显示当前选中的提示词 */}
        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600 leading-relaxed">
            <span className="font-medium">当前分析提示：</span>
            {customPrompt}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}