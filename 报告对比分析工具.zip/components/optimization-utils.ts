import { CheckCircle, TrendingUp, Target, Star } from 'lucide-react';
import { ComparisonResult, AdvantageItem, ImprovementItem, MetricsComparison } from './types';

export function extractMetrics(
  result: ComparisonResult, 
  selectedPerspective: 'report1' | 'report2'
): MetricsComparison {
  return {
    dataQuality: result.analysis.dimensions.dataQuality[selectedPerspective],
    structure: result.analysis.dimensions.structure[selectedPerspective],
    logic: result.analysis.dimensions.logic[selectedPerspective],
    content: result.analysis.dimensions.content[selectedPerspective],
    wordCount: result.metrics.wordCount[selectedPerspective],
    dataValidationCount: result.metrics.dataValidation.filter(v => 
      v.source === selectedPerspective || v.source === 'both'
    ).length
  };
}

export function calculateOverallScore(metrics: MetricsComparison): number {
  return (metrics.dataQuality + metrics.structure + metrics.logic + metrics.content) / 4 * 100;
}

export function getScoreColor(score: number): string {
  if (score >= 80) return 'text-green-600';
  if (score >= 60) return 'text-yellow-600';
  return 'text-red-600';
}

export function getScoreBg(score: number): string {
  if (score >= 80) return 'bg-green-100';
  if (score >= 60) return 'bg-yellow-100';
  return 'bg-red-100';
}

export function generateAdvantagesAndImprovements(
  currentMetrics: MetricsComparison,
  otherMetrics: MetricsComparison
): { advantages: AdvantageItem[]; improvements: ImprovementItem[] } {
  const advantages: AdvantageItem[] = [];
  const improvements: ImprovementItem[] = [];

  // 数据质量对比
  if (currentMetrics.dataQuality > otherMetrics.dataQuality) {
    advantages.push({
      icon: <CheckCircle className="h-4 w-4" />,
      title: '数据质量优势',
      description: `数据质量得分高出${((currentMetrics.dataQuality - otherMetrics.dataQuality) * 100).toFixed(1)}分`,
      impact: 'high'
    });
  } else {
    improvements.push({
      icon: <CheckCircle className="h-4 w-4" />,
      title: '提升数据质量',
      description: '改进数据来源可靠性，增强数据验证机制',
      priority: 'high',
      actions: [
        '使用更权威的数据源',
        '增加数据验证环节',
        '完善数据注释说明'
      ]
    });
  }

  // 结构框架对比
  if (currentMetrics.structure > otherMetrics.structure) {
    advantages.push({
      icon: <Target className="h-4 w-4" />,
      title: '结构框架优势',
      description: `结构合理性得分高出${((currentMetrics.structure - otherMetrics.structure) * 100).toFixed(1)}分`,
      impact: 'high'
    });
  } else {
    improvements.push({
      icon: <Target className="h-4 w-4" />,
      title: '优化结构框架',
      description: '学习对方报告的结构设计，提升信息组织效果',
      priority: 'high',
      actions: [
        '重新梳理内容层次',
        '优化章节安排',
        '改进信息流转逻辑'
      ]
    });
  }

  // 逻辑推理对比
  if (currentMetrics.logic > otherMetrics.logic) {
    advantages.push({
      icon: <Star className="h-4 w-4" />,
      title: '逻辑推理优势',
      description: `逻辑严密性得分高出${((currentMetrics.logic - otherMetrics.logic) * 100).toFixed(1)}分`,
      impact: 'medium'
    });
  } else {
    improvements.push({
      icon: <Star className="h-4 w-4" />,
      title: '加强逻辑推理',
      description: '增强论证逻辑，提升推理严密性',
      priority: 'medium',
      actions: [
        '明确因果关系',
        '补充论证环节',
        '减少逻辑跳跃'
      ]
    });
  }

  // 内容深度对比
  if (currentMetrics.content > otherMetrics.content) {
    advantages.push({
      icon: <TrendingUp className="h-4 w-4" />,
      title: '内容深度优势',
      description: `内容深度得分高出${((currentMetrics.content - otherMetrics.content) * 100).toFixed(1)}分`,
      impact: 'medium'
    });
  } else {
    improvements.push({
      icon: <TrendingUp className="h-4 w-4" />,
      title: '增加内容深度',
      description: '提升分析深度，增强实用价值',
      priority: 'medium',
      actions: [
        '深化关键议题分析',
        '增加实践案例',
        '提供具体操作指导'
      ]
    });
  }

  return { advantages, improvements };
}