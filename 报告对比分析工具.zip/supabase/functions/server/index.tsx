import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { streamSSE } from "npm:hono/streaming";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use("*", logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: [
      "Content-Type",
      "Authorization",
      "Cache-Control",
    ],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length", "Content-Type"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-c4106c46/health", (c) => {
  return c.json({ status: "ok" });
});

// 流式数据点识别和验证
app.post(
  "/make-server-c4106c46/ai/extract-data-points-stream",
  async (c) => {
    console.log(
      "=== Stream Extract Data Points API Called ===",
    );
    try {
      const {
        report1Content,
        report2Content,
        report1Title,
        report2Title,
      } = await c.req.json();

      console.log("Request data:", {
        report1Title,
        report2Title,
        report1ContentLength: report1Content?.length || 0,
        report2ContentLength: report2Content?.length || 0,
      });

      return streamSSE(
        c,
        async (stream) => {
          try {
            await stream.writeSSE({
              data: JSON.stringify({
                type: "progress",
                message: "正在识别数据点...",
                progress: 20,
              }),
            });

            const systemPrompt = `你是一个专业的数据分析师，专门负责从报告中识别和提取数据点。你需要准确识别报告中的所有数值型数据，并将其抽象为有意义的数据类别。`;

            const prompt = `
        请分析以下两份报告，识别并提取所有数据点：

        **报告1：《${report1Title}》**
        ${report1Content.substring(0, 3000)}

        **报告2：《${report2Title}》**
        ${report2Content.substring(0, 3000)}

        要求：
        1. 识别所有数值型数据，也就是说你看到有数字的时候就要判别下这个是不是你要抽取的数值型数据
        2. 将具体数值抽象为数据类别（如"营收数据"、"增长率"、"用户规模、"用户满意度""等）
        3. 将两份报告抽象后的数据类别进行合并，对于 95% 以上相似的数据类别进行去重
        3. 返回JSON格式，包含两个报告合并后的数据类别，以及这些数据类别对应的两份报告的数据点
        4. 对于每个数据类别，提供：category（类别）、value（数据点）、unit（单位）
        5. 合并去重后提供unionCategories数组

        返回格式：
        {
          "report1DataPoints": [{"category": "营收数据", "value": "1250", "unit": "万元"}],
          "report2DataPoints": [{"category": "营收数据", "value": "980", "unit": "万元"}],
          "unionCategories": ["营收数据", "增长率", "用户规模"]
        }
        `;

            await stream.writeSSE({
              data: JSON.stringify({
                type: "progress",
                message: "正在调用AI分析...",
                progress: 40,
              }),
            });

            const response = await fetch(
              "https://api.openai.com/v1/chat/completions",
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
                },
                body: JSON.stringify({
                  model: "gpt-4",
                  messages: [
                    { role: "system", content: systemPrompt },
                    { role: "user", content: prompt },
                  ],
                  max_tokens: 3000,
                  temperature: 0.3,
                  stream: true,
                }),
              },
            );

            if (!response.ok) {
              const errorText = await response.text();
              console.log(
                "OpenAI API error for extract-data-points:",
                {
                  status: response.status,
                  statusText: response.statusText,
                  error: errorText,
                },
              );
              await stream.writeSSE({
                data: JSON.stringify({
                  type: "error",
                  message: `OpenAI API error: ${response.status} ${response.statusText}`,
                }),
              });
              return;
            }

            await stream.writeSSE({
              data: JSON.stringify({
                type: "progress",
                message: "正在处理AI响应...",
                progress: 70,
              }),
            });

            const reader = response.body?.getReader();
            const decoder = new TextDecoder();
            let result = "";

            if (reader) {
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value);
                const lines = chunk.split("\n");

                for (const line of lines) {
                  if (line.startsWith("data: ")) {
                    const data = line.slice(6);
                    if (data === "[DONE]") break;

                    try {
                      const parsed = JSON.parse(data);
                      const content =
                        parsed.choices?.[0]?.delta?.content ||
                        "";
                      result += content;

                      // 流式传输每个token
                      if (content) {
                        await stream.writeSSE({
                          data: JSON.stringify({
                            type: "token",
                            content: content,
                            accumulated: result.length,
                          }),
                        });
                      }
                    } catch (e) {
                      // 忽略解析错误
                    }
                  }
                }
              }
            }

            await stream.writeSSE({
              data: JSON.stringify({
                type: "progress",
                message: "正在解析结果...",
                progress: 90,
              }),
            });

            // 解析最终结果
            try {
              const parsedData = JSON.parse(result);
              console.log(
                "Successfully parsed data points:",
                Object.keys(parsedData),
              );
              await stream.writeSSE({
                data: JSON.stringify({
                  type: "complete",
                  data: parsedData,
                  progress: 100,
                }),
              });
            } catch (parseError) {
              console.log(
                "JSON parse error for extract-data-points:",
                parseError,
                "Raw result:",
                result,
              );
              await stream.writeSSE({
                data: JSON.stringify({
                  type: "complete",
                  data: {
                    report1DataPoints: [],
                    report2DataPoints: [],
                    unionCategories: [],
                  },
                  progress: 100,
                }),
              });
            }
          } catch (error) {
            console.log(
              "Stream extract data points error:",
              error,
            );
            await stream.writeSSE({
              data: JSON.stringify({
                type: "error",
                message: "Internal server error",
              }),
            });
          }
        },
        {
          headers: {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            Connection: "keep-alive",
          },
        },
      );
    } catch (error) {
      console.log("Extract data points error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  },
);

// 保留原有的非流式端点作为备用
app.post(
  "/make-server-c4106c46/ai/extract-data-points",
  async (c) => {
    console.log("=== Extract Data Points API Called ===");
    try {
      const {
        report1Content,
        report2Content,
        report1Title,
        report2Title,
      } = await c.req.json();

      console.log("Request data:", {
        report1Title,
        report2Title,
        report1ContentLength: report1Content?.length || 0,
        report2ContentLength: report2Content?.length || 0,
      });

      // 提示词位置：数据点识别提示词
      const systemPrompt = `你是一个专业的数据分析师，专门负责从报告中识别和提取数据点。你需要准确识别报告中的所有数值型数据，并将其抽象为有意义的数据类别。`;

      const prompt = `
    请分析以下两份报告，识别并提取所有数据点：

    **报告1：《${report1Title}》**
    ${report1Content.substring(0, 3000)}

    **报告2：《${report2Title}》**
    ${report2Content.substring(0, 3000)}

    要求：
    1. 识别所有数值型数据，也就是说你看到有数字的时候就要判别下这个是不是你要抽取的数值型数据
    2. 将具体数值抽象为数据类别（如"营收数据"、"增长率"、"用户规模、"用户满意度""等）
    3. 将两份报告抽象后的数据类别进行合并，对于 95% 以上相似的数据类别进行去重
    3. 返回JSON格式，包含两个报告合并后的数据类别，以及这些数据类别对应的两份报告的数据点
    4. 对于每个数据类别，提供：category（类别）、value（数据点）、unit（单位）
    5. 合并去重后提供unionCategories数组

    返回格式：
    {
      "report1DataPoints": [{"category": "营收数据", "value": "1250", "unit": "万元"}],
      "report2DataPoints": [{"category": "营收数据", "value": "980", "unit": "万元"}],
      "unionCategories": ["营收数据", "增长率", "用户规模"]
    }
    `;

      const response = await fetch(
        "https://api.openai.com/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
          },
          body: JSON.stringify({
            model: "gpt-4",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: prompt },
            ],
            max_tokens: 3000,
            temperature: 0.3,
          }),
        },
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.log(
          "OpenAI API error for extract-data-points:",
          {
            status: response.status,
            statusText: response.statusText,
            error: errorText,
          },
        );
        return c.json(
          {
            error: `OpenAI API error: ${response.status} ${response.statusText}`,
          },
          500,
        );
      }

      const data = await response.json();
      const result = data.choices[0]?.message?.content || "";

      console.log("OpenAI response for extract-data-points:", {
        choices: data.choices?.length || 0,
        resultLength: result.length,
      });

      // 尝试解析JSON，如果失败则返回默认数据
      try {
        const parsedData = JSON.parse(result);
        console.log(
          "Successfully parsed data points:",
          Object.keys(parsedData),
        );
        return c.json(parsedData);
      } catch (parseError) {
        console.log(
          "JSON parse error for extract-data-points:",
          parseError,
          "Raw result:",
          result,
        );
        return c.json({
          report1DataPoints: [],
          report2DataPoints: [],
          unionCategories: [],
        });
      }
    } catch (error) {
      console.log("Extract data points error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  },
);

// 流式生成AI综合评估
app.post(
  "/make-server-c4106c46/ai/generate-comprehensive-analysis-stream",
  async (c) => {
    console.log(
      "=== Stream Generate Comprehensive Analysis API Called ===",
    );
    try {
      const {
        report1Content,
        report2Content,
        report1Title,
        report2Title,
        analysisMode,
        winner,
        analysisModeName,
        analysisDimensionsText,
      } = await c.req.json();

      console.log("Request data for comprehensive analysis:", {
        report1Title,
        report2Title,
        analysisMode,
        winner,
        analysisModeName,
        analysisDimensionsTextLength:
          analysisDimensionsText?.length || 0,
      });

      return streamSSE(
        c,
        async (stream) => {
          try {
            await stream.writeSSE({
              data: JSON.stringify({
                type: "progress",
                message: "正在生成AI综合评估...",
                progress: 20,
              }),
            });

            const systemPrompt = `你是一个资深的报告分析专家，具备多年的${analysisModeName || getAnalysisTypeDescription(analysisMode)}经验。你需要基于选定的分析维度对两份报告进行深度对比分析。`;

            const prompt = `
        请基于【${analysisModeName || getAnalysisTypeDescription(analysisMode)}】模式，对以下两份报告进行综合评估：

        **报告1：《${report1Title}》**
        ${report1Content.substring(0, 2000)}

        **报告2：《${report2Title}》**
        ${report2Content.substring(0, 2000)}

        **分析要求：**
        1. 生成一句话结论（30-50字）：简明扼要地总结对比结果
        2. 生成详细分析段落：深入阐述【${analysisModeName || getAnalysisTypeDescription(analysisMode)}】方面的优劣势对比

        **分析重点：**
        ${analysisDimensionsText || getAnalysisPromptDetails(analysisMode)}

        **当前判定结果：**${winner === "report1" ? `《${report1Title}》质量更优` : winner === "report2" ? `《${report2Title}》质量更优` : "两份报告质量相当"}

        **关键指令：**
        请确保返回的 detailedAnalysis 是一段包含多个小标题的 Markdown 格式文本，每个小标题的名字必须严格来自于上述「分析重点」中提到的维度。例如，如果分析重点提到"方法论"、"创新价值"等维度，则返回的文本应该是：

        ### 方法论
        xxxx

        ### 创新价值  
        xxxx

        请返回JSON格式：
        {
          "conclusion": "一句话结论",
          "detailedAnalysis": "带有 Markdown 小标题的详细分析段落"
        }
        `;

            await stream.writeSSE({
              data: JSON.stringify({
                type: "progress",
                message: "正在调用AI分析...",
                progress: 40,
              }),
            });

            const response = await fetch(
              "https://api.openai.com/v1/chat/completions",
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
                },
                body: JSON.stringify({
                  model: "gpt-4o",
                  messages: [
                    { role: "system", content: systemPrompt },
                    { role: "user", content: prompt },
                  ],
                  max_tokens: 1000,
                  temperature: 0.8,
                  stream: true,
                }),
              },
            );

            if (!response.ok) {
              const errorText = await response.text();
              console.log(
                "OpenAI API error for comprehensive-analysis:",
                {
                  status: response.status,
                  statusText: response.statusText,
                  error: errorText,
                },
              );
              await stream.writeSSE({
                data: JSON.stringify({
                  type: "error",
                  message: `OpenAI API error: ${response.status} ${response.statusText}`,
                }),
              });
              return;
            }

            await stream.writeSSE({
              data: JSON.stringify({
                type: "progress",
                message: "正在处理AI响应...",
                progress: 70,
              }),
            });

            const reader = response.body?.getReader();
            const decoder = new TextDecoder();
            let result = "";

            if (reader) {
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value);
                const lines = chunk.split("\n");

                for (const line of lines) {
                  if (line.startsWith("data: ")) {
                    const data = line.slice(6);
                    if (data === "[DONE]") break;

                    try {
                      const parsed = JSON.parse(data);
                      const content =
                        parsed.choices?.[0]?.delta?.content ||
                        "";
                      result += content;

                      // 流式传输每个token
                      if (content) {
                        await stream.writeSSE({
                          data: JSON.stringify({
                            type: "token",
                            content: content,
                            accumulated: result.length,
                          }),
                        });
                      }
                    } catch (e) {
                      // 忽略解析错误
                    }
                  }
                }
              }
            }

            await stream.writeSSE({
              data: JSON.stringify({
                type: "progress",
                message: "正在解析结果...",
                progress: 90,
              }),
            });

            // 解析最终结果
            try {
              const parsedData = JSON.parse(result);
              console.log(
                "Successfully parsed comprehensive analysis:",
                Object.keys(parsedData),
              );
              await stream.writeSSE({
                data: JSON.stringify({
                  type: "complete",
                  data: parsedData,
                  progress: 100,
                }),
              });
            } catch (parseError) {
              console.log(
                "JSON parse error for comprehensive-analysis:",
                parseError,
                "Raw result:",
                result,
              );
              await stream.writeSSE({
                data: JSON.stringify({
                  type: "complete",
                  data: {
                    conclusion:
                      "基于当前分析维度，两份报告各有特色，需要进一步深入对比。",
                    detailedAnalysis:
                      "在当前分析框架下，两份报告在结构完整性、内容深度、数据质量和逻辑严密性等方面表现出不同的特点。建议结合具体业务场景和应用目标，进行更加细化的专项分析，以准确评估各自的优势和改进空间。",
                  },
                  progress: 100,
                }),
              });
            }
          } catch (error) {
            console.log(
              "Stream comprehensive analysis error:",
              error,
            );
            await stream.writeSSE({
              data: JSON.stringify({
                type: "error",
                message: "Internal server error",
              }),
            });
          }
        },
        {
          headers: {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            Connection: "keep-alive",
          },
        },
      );
    } catch (error) {
      console.log(
        "Generate comprehensive analysis error:",
        error,
      );
      return c.json({ error: "Internal server error" }, 500);
    }
  },
);

// 生成数据验证建议
app.post(
  "/make-server-c4106c46/ai/generate-data-validation",
  async (c) => {
    try {
      const { category, report1Value, report2Value, status } =
        await c.req.json();

      // 提示词位置：数据验证建议提示词
      const systemPrompt = `你是一个专业的数据验证专家，负责对报告中的数据一致性问题提供专业建议。`;

      const prompt = `
    数据类别：${category}
    报告1数值：${report1Value || "无数据"}
    报告2数值：${report2Value || "无数据"}
    验证状态：${status}

    请根据以上信息生成简洁的AI建议（15-30字）：
    - 如果数据一致，说明数据可靠，只说明"数据可靠"
    - 如果数据存疑，说明可能的原因和建议
    - 如果数据缺失，说明影响和建议
    `;

      const response = await fetch(
        "https://api.openai.com/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
          },
          body: JSON.stringify({
            model: "gpt-4",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: prompt },
            ],
            max_tokens: 150,
            temperature: 0.5,
          }),
        },
      );

      if (!response.ok) {
        return c.json({ suggestion: "建议进一步核实数据来源" });
      }

      const data = await response.json();
      const suggestion =
        data.choices[0]?.message?.content ||
        "建议进一步核实数据来源";

      return c.json({ suggestion });
    } catch (error) {
      console.log("Generate data validation error:", error);
      return c.json({ suggestion: "建议进一步核实数据来源" });
    }
  },
);

// 保留原有的非流式端点
app.post(
  "/make-server-c4106c46/ai/generate-comprehensive-analysis",
  async (c) => {
    console.log(
      "=== Generate Comprehensive Analysis API Called ===",
    );
    try {
      const {
        report1Content,
        report2Content,
        report1Title,
        report2Title,
        analysisMode,
        winner,
        analysisModeName,
        analysisDimensionsText,
      } = await c.req.json();

      console.log("Request data for comprehensive analysis:", {
        report1Title,
        report2Title,
        analysisMode,
        winner,
        analysisModeName,
        analysisDimensionsTextLength:
          analysisDimensionsText?.length || 0,
        report1ContentLength: report1Content?.length || 0,
        report2ContentLength: report2Content?.length || 0,
      });

      // 提示词位置：AI综合评估提示词
      const systemPrompt = `你是一个资深的报告分析专家，具备多年的${analysisModeName || getAnalysisTypeDescription(analysisMode)}经验。你需要基于选定的分析维度对两份报告进行深度对比分析。`;

      const prompt = `
    请基于【${analysisModeName || getAnalysisTypeDescription(analysisMode)}】模式，对以下两份报告进行综合评估：

    **报告1：《${report1Title}》**
    ${report1Content.substring(0, 2000)}

    **报告2：《${report2Title}》**
    ${report2Content.substring(0, 2000)}

    **分析要求：**
    1. 生成一句话结论（30-50字）：简明扼要地总结对比结果
    2. 生成详细分析段落：深入阐述【${analysisModeName || getAnalysisTypeDescription(analysisMode)}】方面的优劣势对比

    **分析重点：**
    ${analysisDimensionsText || getAnalysisPromptDetails(analysisMode)}

    **当前判定结果：**${winner === "report1" ? `《${report1Title}》质量更优` : winner === "report2" ? `《${report2Title}》质量更优` : "两份报告质量相当"}

    **关键指令：**
    请确保返回的 detailedAnalysis 是一段包含多个小标题的 Markdown 格式文本，每个小标题的名字必须严格来自于上述「分析重点」中提到的维度。例如，如果分析重点提到"方法论"、"创新价值"等维度，则返回的文本应该是：

    ### 方法论
    xxxx

    ### 创新价值  
    xxxx

    请返回JSON格式：
    {
      "conclusion": "一句话结论",
      "detailedAnalysis": "带有 Markdown 小标题的详细分析段落"
    }
    `;

      const response = await fetch(
        "https://api.openai.com/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
          },
          body: JSON.stringify({
            model: "gpt-4o",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: prompt },
            ],
            max_tokens: 1000,
            temperature: 0.8,
          }),
        },
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.log(
          "OpenAI API error for comprehensive-analysis:",
          {
            status: response.status,
            statusText: response.statusText,
            error: errorText,
          },
        );
        return c.json(
          {
            error: `OpenAI API error: ${response.status} ${response.statusText}`,
          },
          500,
        );
      }

      const data = await response.json();
      const result = data.choices[0]?.message?.content || "";

      console.log(
        "OpenAI response for comprehensive-analysis:",
        {
          choices: data.choices?.length || 0,
          resultLength: result.length,
        },
      );

      try {
        const parsedData = JSON.parse(result);
        console.log(
          "Successfully parsed comprehensive analysis:",
          Object.keys(parsedData),
        );
        return c.json(parsedData);
      } catch (parseError) {
        console.log(
          "JSON parse error for comprehensive-analysis:",
          parseError,
          "Raw result:",
          result,
        );
        // 如果JSON解析失败，提供默认内容
        return c.json({
          conclusion:
            "基于当前分析维度，两份报告各有特色，需要进一步深入对比。",
          detailedAnalysis:
            "在当前分析框架下，两份报告在结构完整性、内容深度、数据质量和逻辑严密性等方面表现出不同的特点。建议结合具体业务场景和应用目标，进行更加细化的专项分析，以准确评估各自的优势和改进空间。",
        });
      }
    } catch (error) {
      console.log(
        "Generate comprehensive analysis error:",
        error,
      );
      return c.json({ error: "Internal server error" }, 500);
    }
  },
);

// 生成学习要点的四个维度分析
app.post(
  "/make-server-c4106c46/ai/generate-learning-dimensions",
  async (c) => {
    try {
      const {
        currentReportContent,
        targetReportContent,
        currentReportTitle,
        targetReportTitle,
        analysisMode,
        isWinning,
        analysisModeName,
        analysisDimensionsText,
      } = await c.req.json();

      // 提示词位置：学习维度分析提示词
      const systemPrompt = `你是一个专业的报告分析导师，专门帮助用户从优秀报告中学习改进经验。你需要从提供的分析维度中分析目标报告的优势。`;

      const prompt = `
    **学习目标：** 分析《${targetReportTitle}》的优势，为《${currentReportTitle}》提供改进方向
    **分析维度：** ${analysisModeName || getAnalysisTypeDescription(analysisMode)}
    **当前状态：** ${isWinning ? "当前报告已具优势，寻求进一步提升" : "当前报告需要学习目标报告的先进做法"}

    **目标报告内容：《${targetReportTitle}》**
    ${targetReportContent.substring(0, 2000)}

    **当前报告内容：《${currentReportTitle}》**
    ${currentReportContent.substring(0, 2000)}

    请严格按照【${analysisDimensionsText || getAnalysisPromptDetails(analysisMode)}】中提到的维度，逐一分析目标报告的优势特点（每个维度50-80字）。

    **关键指令：**
    你的返回结果必须是一个 JSON 对象，这个对象的 key 必须严格是上述分析维度中提到的那几个维度，value 是对应的分析。

    例如，如果分析维度提到"方法论"、"创新价值"、"文献基础"、"验证严谨性"、"学术影响"，则应返回：
    {
      "方法论": "分析内容...",
      "创新价值": "分析内容...",
      "文献基础": "分析内容...",
      "验证严谨性": "分析内容...",
      "学术影响": "分析内容..."
    }
    `;

      const response = await fetch(
        "https://api.openai.com/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
          },
          body: JSON.stringify({
            model: "gpt-4",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: prompt },
            ],
            max_tokens: 1000,
            temperature: 0.6,
          }),
        },
      );

      if (!response.ok) {
        console.log("OpenAI API error:", await response.text());
        return c.json({ error: "OpenAI API error" }, 500);
      }

      const data = await response.json();
      const result = data.choices[0]?.message?.content || "";

      try {
        const parsedData = JSON.parse(result);
        return c.json(parsedData);
      } catch (parseError) {
        // 如果JSON解析失败，提供基于当前分析维度的默认内容
        const defaultDimensions: Record<string, string> = {};
        const analysisDetails =
          analysisDimensionsText ||
          getAnalysisPromptDetails(analysisMode);
        const dimensionLines = analysisDetails
          .split("\\n")
          .filter((line) => line.trim().startsWith("-"));
        dimensionLines.forEach((line, index) => {
          const dimensionName = line
            .split("：")[0]
            .replace("- ", "");
          defaultDimensions[dimensionName] =
            `目标报告在${dimensionName}方面表现突出，值得学习借鉴。`;
        });

        return c.json(defaultDimensions);
      }
    } catch (error) {
      console.log("Generate learning dimensions error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  },
);

// 辅助函数：获取分析类型描述
function getAnalysisTypeDescription(mode: string): string {
  const typeMap: Record<string, string> = {
    comprehensive: "综合质量分析",
    data: "数据分析专业性",
    business: "商业价值评估",
    structure: "结构逻辑分析",
    research: "研究深度评估",
  };
  return typeMap[mode] || "综合质量分析";
}

// 辅助函数：获取分析提示词详情
function getAnalysisPromptDetails(mode: string): string {
  const detailMap: Record<string, string> = {
    comprehensive:
      "- 整体结构完整性\\n- 内容丰富度和深度\\n- 数据准确性和可信度\\n- 逻辑严密性和说服力\\n- 实用性和可操作性",
    data: "- 数据来源的权威性\\n- 数据处理的专业性\\n- 数据呈现的清晰度\\n- 数据分析的深度\\n- 数据结论的可靠性",
    business:
      "- 商业模式分析的深度\\n- 市场洞察的准确性\\n- 价值主张的清晰度\\n- 商业可行性评估\\n- 实际应用价值",
    structure:
      "- 整体框架的逻辑性\\n- 章节安排的合理性\\n- 论证结构的严密性\\n- 内容组织的条理性\\n- 表达的清晰度",
    research:
      "- 研究方法的科学性\\n- 分析维度的全面性\\n- 理论深度和广度\\n- 创新观点和见解\\n- 学术价值和贡献",
  };
  return detailMap[mode] || detailMap.comprehensive;
}

app.post(
  "/make-server-c4106c46/ai/generate-summary",
  async (c) => {
    try {
      const {
        reportTitle,
        otherReportTitle,
        isWinning,
        analysisType,
      } = await c.req.json();

      const systemPrompt = `你是一个专业的报告分析师，需要为报告对比分析生成简洁的一句话总结。`;

      const prompt = `
    基于以下信息，生成一句话总结（不超过50字）：
    
    - 当前分析报告：《${reportTitle}》
    - 对比报告：《${otherReportTitle}》
    - 分析结果：${isWinning ? "当前报告质量更优" : "当前报告有提升空间"}
    - 分析维度：${analysisType}
    
    要求：
    1. 一句话总结，不超过50字
    2. 体现分析结果的核心要点
    3. 语言简洁专业
    4. 不要使用"建议"等指令性词汇
    `;

      const response = await fetch(
        "https://api.openai.com/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
          },
          body: JSON.stringify({
            model: "gpt-4",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: prompt },
            ],
            max_tokens: 200,
            temperature: 0.7,
          }),
        },
      );

      if (!response.ok) {
        console.log("OpenAI API error:", await response.text());
        return c.json({ error: "OpenAI API error" }, 500);
      }

      const data = await response.json();
      const summary = data.choices[0]?.message?.content || "";

      return c.json({ summary });
    } catch (error) {
      console.log("Generate summary error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  },
);

app.post(
  "/make-server-c4106c46/ai/generate-actions",
  async (c) => {
    try {
      const {
        reportTitle,
        otherReportTitle,
        isWinning,
        analysisType,
        learningPoints,
      } = await c.req.json();

      const systemPrompt = `你是一个专业的报告优化顾问，需要生成具体的执行项目列表。`;

      const prompt = `
    基于以下信息，生成3-5个具体的执行项目：
    
    - 当前分析报告：《${reportTitle}》
    - 对比报告：《${otherReportTitle}》
    - 分析结果：${isWinning ? "当前报告质量更优" : "当前报告有提升空间"}
    - 分析维度：${analysisType}
    - 学习要点：${learningPoints.join("; ")}
    
    要求：
    1. 每个执行项都是具体可操作的行动
    2. 以动词开头，明确行动目标
    3. 每项15-25字左右
    4. 按重要性排序
    5. 每行一个项目，用换行符分隔
    `;

      const response = await fetch(
        "https://api.openai.com/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
          },
          body: JSON.stringify({
            model: "gpt-4",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: prompt },
            ],
            max_tokens: 500,
            temperature: 0.7,
          }),
        },
      );

      if (!response.ok) {
        console.log("OpenAI API error:", await response.text());
        return c.json({ error: "OpenAI API error" }, 500);
      }

      const data = await response.json();
      const result = data.choices[0]?.message?.content || "";
      const actions = result
        .split("\n")
        .filter((item) => item.trim())
        .slice(0, 5);

      return c.json({ actions });
    } catch (error) {
      console.log("Generate actions error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  },
);

Deno.serve(app.fetch);